Hello everyone!

The purpose of this build is for you to play around in the game world and its mechanics. 
There is no set win condition or goal. Just move around and play around with the game  mechanics. 

Have fun!

Also, for those playing on keyboard, press spacebar when you come across the interactable tutorials instead of pressing the "A" key. 
Keep pressing spacebar/A to go through the tutorial. 
For both keyboard and gamepad players, once it loops back around to "Press A to interact" you can move on.